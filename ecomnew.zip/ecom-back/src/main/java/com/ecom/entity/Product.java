package com.ecom.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ecom_products")
public class Product {
	@Id // for primary
	@GeneratedValue(strategy = GenerationType.AUTO) // for auto increment
	// @Column(name = "product_id") // we awant change the column name the
	private int productid;  
	
	private String productname;
	
	private String productdesc;
	
	private boolean stock;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(int productid, String productname, String productdesc, boolean stock) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productdesc = productdesc;
		this.stock = stock;
		
		
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getProductdesc() {
		return productdesc;
	}
	public void setProductdesc(String productdesc) {
		this.productdesc = productdesc;
	}
	public boolean isStock() {
		return stock;
	}
	public void setStock(boolean stock) {
		this.stock = stock;
	}
	



}
