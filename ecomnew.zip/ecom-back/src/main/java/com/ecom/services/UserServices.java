package com.ecom.services;

import java.util.List;

import com.ecom.payload.UserDto;

public interface UserServices  {
	
	//create
	 UserDto saveUser(UserDto userdto);
	 
	//update
	 UserDto updateUser(int userid,UserDto userdto);
	 
	//getall
	 List<UserDto> getAllUser();
	 
	//getsingle by id
	 UserDto getByUserId(int userid);
	 
	//getsingle by email
		 UserDto getByEmail(String useremail);
	 
	//delete
	 void deleteUser(int userid);
	 
	 
	
	
	
}
