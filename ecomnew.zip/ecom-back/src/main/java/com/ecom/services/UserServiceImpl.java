package com.ecom.services;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecom.entity.User;
import com.ecom.exception.ResourceNotFoundException;
import com.ecom.payload.UserDto;
import com.ecom.repositiory.UserRepository;

@Service
public class UserServiceImpl implements UserServices {
	@Autowired
	private UserRepository userrepository;
	

	@Override
	public UserDto saveUser(UserDto userdto) {
		
		//dto to entity // first we convert 
		User entity = this.toEntity(userdto);
		User save = this.userrepository.save(entity);
		//entity to dto
		return this.toDto(save);
		
		
			}

	@Override
	public UserDto updateUser(int userid, UserDto t) {
		
		User u = this.userrepository.findById(userid).orElseThrow(()-> new ResourceNotFoundException("Resource Not Found"+userid));
		
		u.setName(t.getName());
		u.setEmail(t.getEmail());
		u.setPassword(t.getPassword());
		u.setAbout(t.getAbout());
		u.setAddress(t.getAddress());
		u.setActive(t.isActive());
		u.setGender(t.getGender());
		u.setCreateAt(t.getCreateAt());
		u.setPhone(t.getPhone());
		User update = this.userrepository.save(u);
		return this.toDto(update);
	}

	@Override
	public List<UserDto> getAllUser() {
		List<User> alluser = this.userrepository.findAll();
		List<UserDto> collect = alluser.stream().map(user -> this.toDto(user)).collect(Collectors.toList());
	
		return collect;
	}

	@Override
	public UserDto getByUserId(int userid) {
		User user = this.userrepository.findById(userid).orElseThrow(() -> new ResourceNotFoundException("Resource Not Found"+userid));
		return this.toDto(user);
	}

	@Override
	public UserDto getByEmail(String useremail) {
		User user = this.userrepository.findByEmail(useremail).orElseThrow(() ->new ResourceNotFoundException("Resource Not Found"+useremail));
		return this.toDto(user);
	}

	@Override
	public void deleteUser(int userid) {
		
			User user = this.userrepository.findById(userid).orElseThrow(() -> new ResourceNotFoundException("Resource Not Found"+userid));
			this.userrepository.delete(user);
	}
	
		/// For coversion purpose
	 //isko user denge to ye hame dto denga
	 public UserDto toDto(User user) {
		 
			UserDto dto = new UserDto();
			dto.setUserId(user.getUserId());
			dto.setName(user.getName());
			dto.setEmail(user.getEmail());
			dto.setPassword(user.getPassword());
			dto.setAbout(user.getAbout());
			dto.setAddress(user.getAddress());
			dto.setActive(user.isActive());
			dto.setGender(user.getGender());
			dto.setCreateAt(user.getCreateAt());
			dto.setPhone(user.getPhone());
			return dto;
		
	}
	 
	 //isko dto denge to ye hame   entity denga
	 public User toEntity(UserDto t) {
			User u = new User();
			u.setUserId(t.getUserId());
			u.setName(t.getName());
			u.setEmail(t.getEmail());
			u.setPassword(t.getPassword());
			u.setAbout(t.getAbout());
			u.setAddress(t.getAddress());
			u.setActive(t.isActive());
			u.setGender(t.getGender());
			u.setCreateAt(t.getCreateAt());
			u.setPhone(t.getPhone());

			return u;
		}


}
