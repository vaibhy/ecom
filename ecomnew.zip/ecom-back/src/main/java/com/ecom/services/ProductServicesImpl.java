package com.ecom.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecom.entity.Product;
import com.ecom.repositiory.ProductRepository;
@Service
public class ProductServicesImpl implements ProductServices {

	@Autowired
	private ProductRepository repo;
	@Override
	public Product saveProduct(Product product) {
		Product save = repo.save(product);
		return save;
	}

	@Override
	public List<Product> getAllProduct() {
		List<Product> findAll = repo.findAll();
		return findAll;
	}

	@Override
	public Product getSingleProduct(int prid) {
	 Product product = repo.findById(prid).get();
		return product;
	}

	@Override
	public void deleteProduct(int prid) {
		Product product2 = repo.findById(prid).get();
		repo.delete(product2);
		
	}

	@Override
	public Product updateProduct(int prid, Product product) {
		Product product2 = repo.findById(prid).get();
		product2.setProductname(product.getProductname());
		product2.setProductdesc(product.getProductdesc());
		product2.setStock(product.isStock());
			Product save = repo.save(product2);
		return save;
	}

}
