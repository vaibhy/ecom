package com.ecom.services;

import java.util.List;

import com.ecom.entity.Product;

public interface ProductServices {
	
	public Product saveProduct(Product product);
	public List<Product> getAllProduct();
	public Product getSingleProduct(int prid);
	public void deleteProduct(int prid);
	public Product updateProduct(int prid,Product product);

}
