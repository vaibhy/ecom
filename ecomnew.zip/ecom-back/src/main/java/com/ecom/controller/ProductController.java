package com.ecom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecom.entity.Product;
import com.ecom.services.ProductServicesImpl;

@RestController
@RequestMapping("/product")
public class ProductController {
	@Autowired
	private  ProductServicesImpl productservices;
	// get all
	@PostMapping("/")
	public Product createproduct(@RequestBody Product product)
	{
		Product saveProduct = productservices.saveProduct(product);
		System.out.println(saveProduct);
		return saveProduct;
	
	}
	
	//create
	@GetMapping("/")
	public List<Product> getallproduct()
	{
		List<Product> getallproduct = productservices.getAllProduct();
		System.out.println(getallproduct);
		return getallproduct;
	
	}
	
	//delete
	@DeleteMapping("/{prid}")
	public String deleteproduct(@PathVariable int prid)
	{
		productservices.deleteProduct(prid);
		return  "Product Delete successfully !!";
	}
	
	

	
	
	//update
	@PutMapping("/{prid}")
	public Product updateproduct(@PathVariable int prid,@RequestBody Product product)
	{
		Product product2 = productservices.updateProduct(prid, product);
		return product2;
	
		
		
	}
	
	
	//get 1 // for single we have not use list
	@GetMapping("/{prid}")
	public  Product getsingleproduct(@PathVariable int prid)
	{
		Product singleProduct = (Product) productservices.getSingleProduct(prid);
		return singleProduct;
		
	}
	

}
