package com.ecom.repositiory;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ecom.entity.Product;

@org.springframework.stereotype.Repository
public interface ProductRepository extends JpaRepository<Product,Integer> {

}
