package com.ecom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcomBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
